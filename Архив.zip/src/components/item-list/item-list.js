import React, { Component } from "react";

import "./item-list.css";
import SwapiService from "../../services/swapi-service";
import Spinner from "../spinner";


export default class ItemList extends Component {
  swapiService = new SwapiService();

  constructor() {
    super();
    this.updatePlanet();
  }
  state = {
    planets: {},
    loading: true
  };

  onPlanetLoaded = planets => {
    this.setState({
      planets,
      loading: false
    });
		console.log(this.state.planets);
  };

  updatePlanet() {
    this.swapiService.getAllPlanet().then(res => {
      this.onPlanetLoaded(res);
    });
  }


  render() {
    const { planets, loading } = this.state;
    const { onDetails } = this.props;

    const spinner = loading ? <Spinner /> : null;
    const content = !loading ? planets.map(planet => {
    	const { id, name } = planet;
          return (
            <li key={planet.name} onClick = {() => onDetails(id)} className="list-group-item">
              {name}
            </li>
          );
        }) : null;

    return (
      <ul className="item-list list-group">
        {spinner}
        {content}
      </ul>
    );
  }
}
